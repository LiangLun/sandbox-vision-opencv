In this book OpenCV By Example

Chapter 1 does not have any code.


Chapter 4, 7, 8, 9, 10 and 11 does not contain README.md file.

