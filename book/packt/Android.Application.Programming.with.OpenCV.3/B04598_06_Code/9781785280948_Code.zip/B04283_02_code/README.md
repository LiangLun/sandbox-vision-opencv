Steps to build
==============
* make a build folder
* go to build folder
* execute cmake ..
* execute make

Executables
===========
./sample1
./sample2
./sample3
./Chapter2