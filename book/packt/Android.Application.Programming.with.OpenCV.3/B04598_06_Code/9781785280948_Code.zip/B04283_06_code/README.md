Steps to build
==============
* make a build folder
* go to build folder
* execute cmake ..
* execute make

Executables
===========
./Chapter6 image_classify